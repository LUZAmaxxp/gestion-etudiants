export interface Etudiant {
  id?: number;
  nom: string;
  prenom: string;
  email: string;
  tel: string;
  date_naissance: string;
  filiere: string;
  created_at?: string;
  updated_at?: string;
} 